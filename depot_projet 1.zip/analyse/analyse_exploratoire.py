# -*- coding: utf-8 -*-
"""
Analyse exploratoire – chapitre 4 du rapport de PFE
Plateforme de benchmarking de la durabilité des universités (ESPRIT 2025/2026)

Ce script reproduit les figures 4.1 à 4.8 du rapport à partir du fichier consolidé
'donnees_consolidees (1).xlsx' (à placer dans le même dossier). Chaque figure s'affiche
à l'écran puis est enregistrée dans le dossier 'figures/'.

Outils : pandas, NumPy, matplotlib, seaborn.   Lancement : python analyse_exploratoire.py
Prérequis : pip install pandas numpy matplotlib seaborn openpyxl
"""
import json, os, warnings; warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
import matplotlib.pyplot as plt, seaborn as sns
RED='#A5192E'; GREY='#6B7280'; DARK='#1F2937'
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#9CA3AF','axes.labelcolor':DARK,'xtick.color':DARK,'ytick.color':DARK,'axes.titleweight':'bold','axes.titlesize':11})
os.makedirs('figures',exist_ok=True)
c=pd.read_excel('donnees_consolidees (1).xlsx')   # fichier consolidé du dépôt (même dossier que ce script)
S=['the_overall','the_teaching','the_research','the_citations','the_industry_income','the_international_outlook']
# les fichiers du dépôt sont imputés par la moyenne : on retrouve les lignes imputées (valeur == moyenne exacte)
mask=np.isclose(c['the_overall'],c['the_overall'].mean(),atol=1e-6)
print('imputed rows the_overall',mask.sum(),'expected',13825-8985)
c.loc[mask,S]=np.nan
R={'n_obs':len(c),'n_univ':int(c.university_id.nunique()),'n_countries':int(c.country.nunique())}
print("→ Figure 4.1")
# 1 régions / pays
u=c.drop_duplicates('university_id'); rg=u.region.value_counts(); R['univ_by_region']=rg.to_dict(); R['univ_by_region_pct']=(rg/rg.sum()*100).round(1).to_dict()
ct=u.country.value_counts().head(10); R['top_countries']=ct.to_dict()
fig,ax=plt.subplots(1,2,figsize=(10.5,3.8))
ax[0].barh(rg.index[::-1],rg.values[::-1],color=RED); ax[0].set_title("Universités par région"); 
for i,v in enumerate(rg.values[::-1]): ax[0].text(v+20,i,f"{v:,}".replace(',',' '),va='center',fontsize=8)
ax[0].set_xlim(0,rg.max()*1.15)
ax[1].barh(ct.index[::-1],ct.values[::-1],color=GREY); ax[1].set_title("Dix pays les mieux représentés")
for i,v in enumerate(ct.values[::-1]): ax[1].text(v+5,i,str(v),va='center',fontsize=8)
ax[1].set_xlim(0,ct.max()*1.15)
plt.tight_layout(); plt.savefig('figures/figure_4_1_regions.png',dpi=200); plt.show()
print("→ Figure 4.2")
# 2 distributions
lab={'the_overall':'Score global','the_teaching':'Enseignement','the_research':'Recherche','the_citations':'Citations','the_industry_income':'Revenus industriels','the_international_outlook':'Ouverture internationale'}
fig,ax=plt.subplots(2,3,figsize=(10.5,5.2))
for a,s in zip(ax.ravel(),S):
    v=c[s].dropna(); a.hist(v,bins=30,color=RED,alpha=.9); a.axvline(v.median(),color=DARK,ls='--',lw=1); a.set_title(f"{lab[s]} (médiane {v.median():.1f})",fontsize=9.5)
plt.tight_layout(); plt.savefig('figures/figure_4_2_distributions.png',dpi=200); plt.show()
print("→ Figure 4.3")
# 3 couverture par source
src=pd.DataFrame({'Source':['THE World','THE Impact','THE Disciplines','QS World','ARWU'],'Observations':[11509,8399,9843,1503,210],'Score global renseigné (%)':[8986/11509*100,100,100,600/1503*100,100/210*100]})
fig,ax=plt.subplots(1,2,figsize=(10.5,3.6))
ax[0].bar(src.Source,src.Observations,color=RED); ax[0].set_title('Observations collectées par source'); ax[0].tick_params(axis='x',labelsize=8)
for i,v in enumerate(src.Observations): ax[0].text(i,v+150,f"{v:,}".replace(',',' '),ha='center',fontsize=8)
ax[1].bar(src.Source,src['Score global renseigné (%)'],color=GREY); ax[1].set_ylim(0,115); ax[1].set_title('Part des scores globaux réellement renseignés (%)'); ax[1].tick_params(axis='x',labelsize=8)
for i,v in enumerate(src['Score global renseigné (%)']): ax[1].text(i,v+2,f"{v:.0f} %",ha='center',fontsize=8)
plt.tight_layout(); plt.savefig('figures/figure_4_3_couverture_classements.png',dpi=200); plt.show()
print("→ Figure 4.4")
# 4 évolution
ym=c.groupby('year').agg(n=('university_id','nunique'),moy=('the_overall','mean'),med=('the_overall','median'),nn=('the_overall','count'))
R['by_year']=ym.round(2).reset_index().to_dict('records')
# même établissements présents sur 5 ans
full=c.groupby('university_id').filter(lambda g:g['year'].nunique()==5); fy=full.groupby('year')['the_overall'].mean(); R['by_year_constant_sample']=fy.round(2).to_dict(); R['n_full5']=int(full.university_id.nunique())
fig,ax=plt.subplots(1,2,figsize=(10.5,3.6))
ax[0].bar(ym.index.astype(str),ym.n,color=GREY); ax[0].set_title("Universités présentes par année")
for i,v in enumerate(ym.n): ax[0].text(i,v+30,f"{v:,}".replace(',',' '),ha='center',fontsize=8)
ax[1].plot(ym.index.astype(str),ym.moy,marker='o',color=RED,lw=2,label='Toutes les universités'); ax[1].plot(fy.index.astype(str),fy.values,marker='s',color=DARK,lw=2,ls='--',label=f'Mêmes {R["n_full5"]} universités (5 ans)')
ax[1].set_title("Score global THE moyen"); ax[1].legend(frameon=False,fontsize=8); ax[1].grid(alpha=.25)
plt.tight_layout(); plt.savefig('figures/figure_4_4_evolution.png',dpi=200); plt.show()
print("→ Figure 4.6")
# 5 corrélations
num=S+['n_students','student_staff_ratio','pc_intl_students','impact_overall','sdg17_score']
cm=c[num].copy(); cm.loc[np.isclose(cm['impact_overall'],cm['impact_overall'].mean(),atol=1e-6),['impact_overall','sdg17_score']]=np.nan
cr=cm.corr(method='pearson'); R['corr_overall']=cr['the_overall'].round(2).to_dict()
sp=cm.corr(method='spearman'); R['spearman_overall']=sp['the_overall'].round(2).to_dict()
nm={**lab,'n_students':'Effectif étudiant','student_staff_ratio':'Ratio étudiants/personnel','pc_intl_students':'% étudiants internationaux','impact_overall':'Impact (ODD) global','sdg17_score':'ODD 17'}
fig,ax=plt.subplots(figsize=(7.6,6)); sns.heatmap(cr.rename(index=nm,columns=nm),annot=True,fmt='.2f',cmap='RdBu_r',center=0,vmin=-1,vmax=1,ax=ax,annot_kws={'size':7},linewidths=.4,cbar_kws={'label':'Corrélation de Pearson'})
ax.set_title('Matrice de corrélation des indicateurs'); plt.xticks(rotation=40,ha='right',fontsize=8); plt.yticks(fontsize=8); plt.tight_layout(); plt.savefig('figures/figure_4_6_correlation.png',dpi=200); plt.show()
# pairs max
pairs=cr.where(np.triu(np.ones(cr.shape),1).astype(bool)).stack().dropna().sort_values(ascending=False); R['top_pairs']={' x '.join(k):v for k,v in pairs.head(6).round(2).items()}; R['bottom_pairs']={' x '.join(k):v for k,v in pairs.tail(4).round(2).items()}
print("→ Figure 4.5")
# 6 scatter
d=c.dropna(subset=S).sample(3000,random_state=1)
fig,ax=plt.subplots(1,3,figsize=(11,3.5))
for a,s in zip(ax,['the_research','the_citations','the_international_outlook']):
    a.scatter(d[s],d['the_overall'],s=6,alpha=.4,color=RED); a.set_xlabel(lab[s]); a.set_ylabel('Score global'); a.grid(alpha=.2)
    r=c[[s,'the_overall']].corr().iloc[0,1]; a.set_title(f"r = {r:.2f}",fontsize=10)
plt.tight_layout(); plt.savefig('figures/figure_4_5_bivariee.png',dpi=200); plt.show()
print("→ Figure 4.8")
# 7 région score moyen
rs=c.groupby('region').agg(moy=('the_overall','mean'),n=('university_id','nunique'),sd=('the_overall','std')).sort_values('moy'); R['by_region']=rs.round(2).reset_index().to_dict('records')
fig,ax=plt.subplots(figsize=(7.2,3.6)); ax.barh(rs.index,rs.moy,color=RED)
for i,(m,n) in enumerate(zip(rs.moy,rs.n)): ax.text(m+.4,i,f"{m:.1f}  (n = {n})",va='center',fontsize=8)
ax.set_xlim(0,rs.moy.max()*1.3); ax.set_title('Score global THE moyen par région'); plt.tight_layout(); plt.savefig('figures/figure_4_8_score_par_region.png',dpi=200); plt.show()
# pays
cs=c.groupby('country').agg(moy=('the_overall','mean'),n=('university_id','nunique')); cs=cs.dropna()[cs.dropna().n>=15].sort_values('moy',ascending=False); R['top_country_score']=cs.head(5).round(1).reset_index().to_dict('records'); R['bottom_country_score']=cs.tail(5).round(1).reset_index().to_dict('records')
print("→ Figure 4.7")
# 8 deux universités (dernière année)
l=c[(c.year==2025)].dropna(subset=S)
# radar
sel=['University of Tunis El Manar','University of Sfax']
L=l.set_index('university_name').loc[sel,S]; R['compare']=L.round(1).reset_index().to_dict('records')
ang=np.linspace(0,2*np.pi,len(S),endpoint=False).tolist(); ang+=ang[:1]
fig=plt.figure(figsize=(5.6,4.6)); ax=fig.add_subplot(111,polar=True)
for (n,row),col in zip(L.iterrows(),[RED,'#2C7FB8']):
    v=row.tolist()+row.tolist()[:1]; ax.plot(ang,v,color=col,lw=2,label=n); ax.fill(ang,v,color=col,alpha=.15)
ax.set_xticks(ang[:-1]); ax.set_xticklabels([lab[s].replace(' ','\n',1) for s in S],fontsize=8); ax.set_ylim(0,80); ax.set_yticks([20,40,60,80]); ax.tick_params(axis='y',labelsize=7)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.08),frameon=False,fontsize=8); ax.set_title('Comparaison de deux universités tunisiennes (THE 2025)',fontsize=10,fontweight='bold',pad=18)
plt.tight_layout(); plt.savefig('figures/figure_4_7_comparaison.png',dpi=200); plt.show()
print('Observations :',R['n_obs'],'| universités :',R['n_univ'],'| pays :',R['n_countries'])
print('Universités présentes les 5 ans :',R['n_full5'])
print('Corrélation avec le score global (Pearson) :',R['corr_overall'])
