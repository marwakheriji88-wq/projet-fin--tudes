# -*- coding: utf-8 -*-
"""
Clustering, classification et explicabilité – chapitre 5 du rapport de PFE
Reproduit les figures 5.2, 5.3, 5.5, 5.7 à 5.12 du rapport à partir de l'entrepôt (universite_dw.sql,
à placer dans le même dossier). Les figures s'affichent puis sont enregistrées dans 'figures/'.
Outils : pandas, scikit-learn, XGBoost, SHAP, matplotlib, seaborn.
Prérequis : pip install pandas numpy scikit-learn xgboost shap matplotlib seaborn
Lancement : python modelisation_clustering_classification.py
"""
import os, re, sqlite3, json, warnings
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import (silhouette_score, davies_bouldin_score, accuracy_score, precision_recall_fscore_support,
                             confusion_matrix, roc_auc_score, f1_score)
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier

RED='#A5192E'; GREY='#6B7280'; DARK='#1F2937'
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#9CA3AF',
                     'axes.labelcolor':DARK,'xtick.color':DARK,'ytick.color':DARK,'axes.titleweight':'bold','axes.titlesize':11,'figure.dpi':100})
R={}
os.makedirs('figures',exist_ok=True)
sql=open('universite_dw.sql',encoding='utf-8').read().replace("\\'","''")
creates=[re.sub(r'\)\s*ENGINE=\w+[^;]*;',');',c) for c in re.findall(r'CREATE TABLE `.*?;\n',sql,re.S)]
inserts=re.findall(r'INSERT INTO `.*?;\n',sql,re.S)
conn=sqlite3.connect(':memory:'); cur=conn.cursor()
for s in creates: cur.execute(s)
for s in inserts: cur.execute(s)
conn.commit()
the=pd.read_sql("SELECT * FROM dim_classement_the_monde",conn); qs=pd.read_sql("SELECT * FROM dim_classement_qs_monde",conn); arwu=pd.read_sql("SELECT * FROM dim_classement_arwu_shanghai",conn)
du=pd.read_sql("SELECT country, region FROM dim_universite",conn).drop_duplicates('country')
c2r=dict(zip(du.country,du.region))
def nk(s):
    s=s.str.lower().str.normalize('NFKD').str.encode('ascii',errors='ignore').str.decode('utf-8')
    return s.str.replace(r'[^a-z0-9 ]','',regex=True).str.strip()
for d in (the,qs,arwu): d['name_key']=nk(d['name'])
feats=['the_overall','the_teaching','the_research','the_citations','the_industry_income','the_international_outlook']
Xs=StandardScaler().fit_transform(the[feats].fillna(the[feats].median()))
# --- choix de k
ks=list(range(2,11)); ine=[];sil=[];dbi=[]
for k in ks:
    km=KMeans(n_clusters=k,random_state=42,n_init=10).fit(Xs); ine.append(km.inertia_)
    sil.append(silhouette_score(Xs,km.labels_,sample_size=5000,random_state=42)); dbi.append(davies_bouldin_score(Xs,km.labels_))
R['k_curves']={'k':ks,'inertia':ine,'silhouette':sil,'davies_bouldin':dbi}
fig,ax=plt.subplots(1,3,figsize=(11,3.4))
for a,y,t in zip(ax,[ine,sil,dbi],["Inertie intra-groupe (coude)","Score de silhouette","Indice de Davies-Bouldin"]):
    a.plot(ks,y,marker='o',color=RED,lw=2); a.set_title(t); a.set_xlabel('Nombre de clusters k'); a.axvline(5,color=GREY,ls='--',lw=1); a.grid(alpha=.25)
plt.tight_layout(); plt.savefig('figures/figure_5_2_choix_k.png',dpi=200); plt.show()
# --- clustering k=5 (identique au notebook)
km=KMeans(n_clusters=5,random_state=42,n_init=10); the['cluster']=km.fit_predict(Xs)
R['silhouette_k5_full']=float(silhouette_score(Xs,the['cluster'])); R['dbi_k5']=float(davies_bouldin_score(Xs,the['cluster']))
order=the.groupby('cluster')['the_overall'].mean().sort_values().index.tolist()
labs=['Faible','Moyen','Bon','Tres bon','Elite']; the['categorie']=the['cluster'].map(dict(zip(order,labs)))
prof=the.groupby('categorie')[feats+['n_students']].mean().reindex(labs)
prof['effectif']=the['categorie'].value_counts().reindex(labs)
R['profil']=prof.round(2).reset_index().to_dict('records')
the['region']=the['country'].map(c2r)
reg=pd.crosstab(the['categorie'],the['region'],normalize='index').reindex(labs)*100
R['regions_par_categorie']=reg.round(1).reset_index().to_dict('records')
R['top_regions']={c:reg.loc[c].sort_values(ascending=False).head(2).round(1).to_dict() for c in labs}
yc=pd.crosstab(the['year'],the['categorie'])[labs]; R['cat_par_annee']=yc.reset_index().to_dict('records')
# PCA
pca=PCA(n_components=2,random_state=42); P=pca.fit_transform(Xs); R['pca_var']=[float(v) for v in pca.explained_variance_ratio_]
fig,ax=plt.subplots(figsize=(6.4,4.6)); pal=['#9CA3AF','#6BAED6','#2CA58D','#E8A33D',RED]
smp=np.random.RandomState(1).choice(len(P),4000,replace=False)
for c,col in zip(labs,pal):
    m=(the['categorie'].values[smp]==c); ax.scatter(P[smp][m,0],P[smp][m,1],s=7,alpha=.6,color=col,label=c)
ax.set_xlabel(f"Composante 1 ({pca.explained_variance_ratio_[0]*100:.1f} % de la variance)"); ax.set_ylabel(f"Composante 2 ({pca.explained_variance_ratio_[1]*100:.1f} %)")
ax.legend(title='Catégorie',markerscale=2.2,frameon=False); ax.set_title('Projection des clusters (ACP)'); ax.grid(alpha=.2)
plt.tight_layout(); plt.savefig('figures/figure_5_3_acp_clusters.png',dpi=200); plt.show()
# centroid heatmap (z-scores)
cz=pd.DataFrame(Xs,columns=feats).groupby(the['categorie'].values).mean().reindex(labs)
fig,ax=plt.subplots(figsize=(7.2,3.4))
sns.heatmap(cz.T.rename(index={'the_overall':'Score global','the_teaching':'Enseignement','the_research':'Recherche','the_citations':'Citations','the_industry_income':'Revenus industriels','the_international_outlook':'Ouverture internationale'}),annot=True,fmt='.2f',cmap='RdBu_r',center=0,cbar_kws={'label':'Écart à la moyenne (z-score)'},ax=ax,linewidths=.5)
ax.set_xlabel('');ax.set_ylabel('');ax.set_title('Profil moyen (centroïdes standardisés) de chaque catégorie'); plt.tight_layout(); plt.savefig('figures/figure_5_5_centroides.png',dpi=200); plt.show()
# --- jeu de transitions
full=the.groupby('name').filter(lambda g:g['year'].nunique()==5).copy(); R['n_univ_full']=int(full['name'].nunique())
om={'Faible':0,'Moyen':1,'Bon':2,'Tres bon':3,'Elite':4}
def tl(a,b): a,b=om[a],om[b]; return 'Monte' if b>a else ('Descend' if b<a else 'Stable')
qsf=qs.groupby('name_key').agg(qs_overall=('qs_overall','mean'),qs_employer_reputation=('qs_employer_reputation','mean'),qs_employment_outcomes=('qs_employment_outcomes','mean')).reset_index()
arf=arwu.groupby('name_key').agg(arwu_score=('arwu_score','mean')).reset_index()
rows=[]
for nm,g in full.groupby('name'):
    g=g.set_index('year'); key=g['name_key'].iloc[0]
    for y1,y2 in [(2021,2022),(2022,2023),(2023,2024),(2024,2025)]:
        r1=g.loc[y1]; c1,c2=r1['categorie'],g.loc[y2]['categorie']
        rows.append({'name':nm,'name_key':key,'year_from':y1,'year_to':y2,'country':r1['country'],'cat_from':c1,**{f:r1[f] for f in feats},'n_students':r1['n_students'],'student_staff_ratio':r1['student_staff_ratio'],'pc_intl_students':r1['pc_intl_students'],'target':tl(c1,c2)})
ds=pd.DataFrame(rows).merge(qsf,on='name_key',how='left').merge(arf,on='name_key',how='left')
cross=['qs_overall','qs_employer_reputation','qs_employment_outcomes','arwu_score']; ds[cross]=ds[cross].fillna(0)
R['dataset_shape']=list(ds.shape); R['target_counts']=ds['target'].value_counts().to_dict()
fn=feats+['n_students','student_staff_ratio','pc_intl_students']+cross; fc=['cat_from','country']
train=ds[ds.year_to<2025]; test=ds[ds.year_to==2025]; R['train_n']=len(train); R['test_n']=len(test)
R['test_counts']=test['target'].value_counts().to_dict(); R['train_counts']=train['target'].value_counts().to_dict()
R['n_features']={'num':len(fn),'cat':len(fc)}
tab=pd.crosstab(ds['cat_from'],ds['target'],normalize='index').reindex(labs)*100
R['transition_by_cat']=tab.round(1).reset_index().to_dict('records'); R['transition_by_cat_n']=ds['cat_from'].value_counts().reindex(labs).to_dict()
pre=ColumnTransformer([('num',StandardScaler(),fn),('cat',OneHotEncoder(handle_unknown='ignore'),fc)])
le=LabelEncoder(); ytr=le.fit_transform(train['target']); sw=compute_sample_weight('balanced',train['target'])
models={'Régression logistique':LogisticRegression(max_iter=1000,class_weight='balanced'),
 'Random Forest':RandomForestClassifier(n_estimators=300,max_depth=8,class_weight='balanced',random_state=42),
 'XGBoost':XGBClassifier(n_estimators=300,max_depth=5,learning_rate=0.1,objective='multi:softprob',eval_metric='mlogloss',random_state=42),
 'Gradient Boosting':GradientBoostingClassifier(n_estimators=300,max_depth=3,random_state=42),
 'SVM':SVC(kernel='rbf',C=1.0,class_weight='balanced',probability=True,random_state=42),
 'K plus proches voisins':KNeighborsClassifier(n_neighbors=15)}
res={}; fitted={}
yte=test['target'].values
for n,m in models.items():
    p=Pipeline([('prep',pre),('clf',m)])
    if n=='XGBoost': p.fit(train[fn+fc],ytr,clf__sample_weight=sw); proba=p.predict_proba(test[fn+fc]); pred=le.inverse_transform(proba.argmax(1)); classes=list(le.classes_)
    else: p.fit(train[fn+fc],train['target']); proba=p.predict_proba(test[fn+fc]); pred=p.predict(test[fn+fc]); classes=list(p.classes_)
    pr,rc,f1,_=precision_recall_fscore_support(yte,pred,average='macro',zero_division=0)
    pc=precision_recall_fscore_support(yte,pred,labels=['Descend','Monte','Stable'],zero_division=0)
    auc=roc_auc_score(pd.get_dummies(yte)[classes].values,proba,average='macro')
    res[n]={'accuracy':accuracy_score(yte,pred),'precision_macro':pr,'recall_macro':rc,'f1_macro':f1,'roc_auc_macro':auc,
            'per_class':{c:{'p':float(pc[0][i]),'r':float(pc[1][i]),'f1':float(pc[2][i]),'n':int(pc[3][i])} for i,c in enumerate(['Descend','Monte','Stable'])},
            'pred_counts':pd.Series(pred).value_counts().to_dict()}
    fitted[n]=(p,pred,proba,classes)
R['models']=res; R['majority_baseline']=float((yte=='Stable').mean())
# comparaison metrics figure
dfm=pd.DataFrame({n:{'Exactitude':r['accuracy'],'F1 macro':r['f1_macro'],'Rappel macro':r['recall_macro']} for n,r in res.items()}).T.sort_values('Exactitude',ascending=False)
fig,ax=plt.subplots(figsize=(8,4)); w=.26; x=np.arange(len(dfm))
for i,(c,col) in enumerate(zip(dfm.columns,[RED,'#6BAED6',GREY])):
    b=ax.bar(x+(i-1)*w,dfm[c],w,label=c,color=col)
ax.set_xticks(x); ax.set_xticklabels([t.replace(' ','\n',1) if len(t)>12 else t for t in dfm.index],fontsize=8); ax.set_ylim(0,1); ax.legend(frameon=False,ncol=3,loc='upper right'); ax.set_title('Comparaison des modèles de classification (test 2024 → 2025)'); ax.grid(axis='y',alpha=.25)
ax.axhline(R['majority_baseline'],color=DARK,ls=':',lw=1); ax.text(len(dfm)-.5,R['majority_baseline']+.015,'part de la classe Stable',ha='right',fontsize=7.5,color=DARK)
plt.tight_layout(); plt.savefig('figures/figure_5_7_comparaison_modeles.png',dpi=200); plt.show()
# confusion matrices RF, KNN
lab3=['Monte','Stable','Descend']
for n,fname in [('Random Forest','figure_5_9_cm_random_forest'),('K plus proches voisins','figure_5_8_cm_knn'),('XGBoost','figure_5_xx_cm_xgboost')]:
    cm=confusion_matrix(yte,fitted[n][1],labels=lab3); R['cm_'+fname]=cm.tolist()
    fig,ax=plt.subplots(figsize=(4.8,3.9)); sns.heatmap(cm,annot=True,fmt='d',cmap='Reds',xticklabels=lab3,yticklabels=lab3,ax=ax,cbar=False,linewidths=.5)
    ax.set_xlabel('Prédit'); ax.set_ylabel('Réel'); ax.set_title(f'Matrice de confusion — {n}',fontsize=10); plt.tight_layout(); plt.savefig(f'figures/{fname}.png',dpi=200); plt.show()
# --- importance par permutation (RF et XGB) sur test, F1 macro
from sklearn.inspection import permutation_importance
def perm(n):
    p=fitted[n][0]; X=test[fn+fc]
    if n=='XGBoost':
        yy=le.transform(yte)
        sc=lambda est,X_,y_: f1_score(y_,est.predict(X_),average='macro')
    else:
        yy=yte; sc=lambda est,X_,y_: f1_score(y_,est.predict(X_),average='macro')
    r=permutation_importance(p,X,yy,scoring=sc,n_repeats=10,random_state=42)
    return pd.Series(r.importances_mean,index=fn+fc).sort_values(ascending=False)
pi=perm('Random Forest'); R['perm_rf']=pi.round(4).head(10).to_dict()
fig,ax=plt.subplots(figsize=(6.4,4)); t=pi.head(10)[::-1]; ax.barh(t.index,t.values,color=RED); ax.set_xlabel('Baisse du F1 macro quand la variable est permutée'); ax.set_title('Importance par permutation — Random Forest'); ax.grid(axis='x',alpha=.25)
plt.tight_layout(); plt.savefig('figures/figure_5_10_importance_permutation.png',dpi=200); plt.show()
# --- SHAP sur RF déployé
import shap
rf=fitted['Random Forest'][0]; Xt=pre.transform(test[fn+fc]); 
names=list(pre.get_feature_names_out()); names=[x.replace('num__','').replace('cat__','') for x in names]
Xd=Xt.toarray() if hasattr(Xt,'toarray') else np.asarray(Xt)
expl=shap.TreeExplainer(rf.named_steps['clf']); sv=expl.shap_values(Xd)
sv=np.array(sv) if isinstance(sv,list) else np.transpose(sv,(2,0,1))  # (classes, n, f)
cls=list(rf.named_steps['clf'].classes_)
R['shap_classes']=cls
glob={}
for i,c in enumerate(cls):
    imp=pd.Series(np.abs(sv[i]).mean(0),index=names).sort_values(ascending=False); glob[c]=imp.head(8).round(4).to_dict()
R['shap_top']=glob
imp_all=pd.Series(np.abs(sv).mean((0,1)),index=names).sort_values(ascending=False); R['shap_top_all']=imp_all.head(10).round(4).to_dict()
mi=cls.index('Monte')
plt.figure(figsize=(7,4.6)); shap.summary_plot(sv[mi],Xd,feature_names=names,show=False,max_display=10,plot_size=None)
plt.title("SHAP — contribution des variables à la prédiction « Monte »",fontsize=10,fontweight='bold'); plt.tight_layout(); plt.savefig('figures/figure_5_11_shap_resume.png',dpi=200,bbox_inches='tight'); plt.show()
# bar global all classes
t=imp_all.head(10)[::-1]; fig,ax=plt.subplots(figsize=(6.4,4)); ax.barh(t.index,t.values,color=RED); ax.set_xlabel('|SHAP| moyen (toutes classes)'); ax.set_title('Importance globale des variables (SHAP) — Random Forest'); ax.grid(axis='x',alpha=.25)
plt.tight_layout(); plt.savefig('figures/shap_bar.png',dpi=200); plt.show()
# explication locale : université prédite Monte avec forte proba
pm=fitted['Random Forest'][2][:,cls.index('Monte')]; j=int(np.argmax(pm)); uname=test.iloc[j]['name']
R['local']={'university':uname,'country':test.iloc[j]['country'],'cat_from':test.iloc[j]['cat_from'],'true':test.iloc[j]['target'],'pred':fitted['Random Forest'][1][j],'p_monte':float(pm[j])}
ex=shap.Explanation(values=sv[mi][j],base_values=expl.expected_value[mi],data=Xd[j],feature_names=names)
plt.figure(); shap.plots.waterfall(ex,max_display=9,show=False); plt.gcf().set_size_inches(7,4.2); plt.tight_layout(); plt.savefig('figures/figure_5_12_shap_local.png',dpi=200,bbox_inches='tight'); plt.show()
R['local_top']=pd.Series(sv[mi][j],index=names).sort_values(key=abs,ascending=False).head(6).round(3).to_dict()

# --- prédictions 2025->2026 avec le Random Forest (modèle déployé)
fut=[]
for nm,g in full.groupby('name'):
    g=g.set_index('year'); r=g.loc[2025]
    fut.append({'name':nm,'name_key':r['name_key'],'country':r['country'],'cat_from':r['categorie'],**{f:r[f] for f in feats},'n_students':r['n_students'],'student_staff_ratio':r['student_staff_ratio'],'pc_intl_students':r['pc_intl_students']})
fut=pd.DataFrame(fut).merge(qsf,on='name_key',how='left').merge(arf,on='name_key',how='left'); fut[cross]=fut[cross].fillna(0)
rfp=fitted['Random Forest'][0]; pr=rfp.predict(fut[fn+fc]); pb=rfp.predict_proba(fut[fn+fc]); cl=list(rfp.classes_)
fut['pred']=pr; fut['p_monte']=pb[:,cl.index('Monte')]; fut['p_desc']=pb[:,cl.index('Descend')]
R['future_rf_counts']=pd.Series(pr).value_counts().to_dict(); R['n_future']=len(fut)
R['future_top_monte']=fut.sort_values('p_monte',ascending=False).head(5)[['name','country','cat_from','p_monte']].round(3).to_dict('records')
R['future_top_desc']=fut.sort_values('p_desc',ascending=False).head(5)[['name','country','cat_from','p_desc']].round(3).to_dict('records')
R['n_features_encoded']=len(names)
print('Exactitude des modèles :',{n:round(r['accuracy'],3) for n,r in R['models'].items()})
print(R['future_rf_counts'],R['n_features_encoded']); print(R['future_top_monte']); print(R['future_top_desc'])

print('silhouette k5',R['silhouette_k5_full'],'dbi',R['dbi_k5']); print(prof.round(1)); print(R['dataset_shape'],R['target_counts'],R['train_n'],R['test_n'])
for n,r in res.items(): print(f"{n:24s} acc={r['accuracy']:.3f} P={r['precision_macro']:.3f} R={r['recall_macro']:.3f} F1={r['f1_macro']:.3f} AUC={r['roc_auc_macro']:.3f}")
print(R['shap_top_all']); print(R['perm_rf']); print(R['local'],R['local_top'])
