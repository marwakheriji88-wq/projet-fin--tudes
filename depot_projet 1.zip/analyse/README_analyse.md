# Dossier `analyse/`

Scripts qui reproduisent les figures du rapport de PFE absentes des notebooks.

| Script | Données à placer dans le même dossier | Figures produites |
|---|---|---|
| `analyse_exploratoire.py` | `donnees_consolidees (1).xlsx` | 4.1 à 4.8 |
| `modelisation_clustering_classification.py` | `universite_dw.sql` | 5.2, 5.3, 5.5, 5.7 à 5.12 |

Exécution : `pip install pandas numpy matplotlib seaborn scikit-learn xgboost shap openpyxl`, puis `python <script>.py`.
Les images enregistrées sont dans `figures/`.
